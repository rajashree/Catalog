#parse("CopyWrite.txt")
#parse("File Header.java")